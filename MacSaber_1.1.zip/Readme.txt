READ THE DISCLAIMER
Then read Compatibility.txt